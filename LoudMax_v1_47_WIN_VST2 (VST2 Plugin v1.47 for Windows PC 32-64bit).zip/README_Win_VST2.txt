LoudMax Loudness Maximizer plugin by Thomas Mundt.
Visit https://loudmax.blogspot.com for updates.
Mail to loudmax@yahoo.de

Disclaimer:
----------
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
USE IT AT YOUR OWN RISK!
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

LoudMax is freeware and not commercial in any mean.
You may not distribute and/or modify LoudMax without having an explicit permission from me.


Installation:
------------
Unfortunately, different locations for VST2 plugins have been used on Windows machines in recent years.
Typical paths are:
C:\Program Files\VSTPlugins
C:\Program Files\Steinberg\VSTPlugins
C:\Program Files\Common Files\VST2
C:\Program Files\Common Files\Steinberg\VST2
32-bit plug-ins on 64-bit Windows: C:\Program Files (x86)\Steinberg\VstPlugins

Try to find out under which path your other VST2 plugins are located and copy the two plugins LoudMax.dll and LoudMax64.dll there.
In case of problems, please refer to the documentation of your audio workstation software.

Usage notes:
-----------
- Hold down the Shift key to adjust the sliders more precisely.
- Click in the lower right corner to toggle the GUI size between Normal and Large.
- The "Fader Link" function works reliably only in the graphical user interface. In the "generic" or "controls" view of some DAW hosts, the link works, but the output fader change is not displayed.

Further informations and tutorials can be found at https://loudmax.blogspot.com

