LoudMax Loudness Maximizer plugin by Thomas Mundt.
Visit https://loudmax.blogspot.com for updates.
Mail to loudmax@yahoo.de

Disclaimer:
----------
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
USE IT AT YOUR OWN RISK!
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

LoudMax is freeware and not commercial in any mean.
You may not distribute and/or modify LoudMax without having an explicit permission from me.


Installation:
------------
Copy the plugin LoudMax.vst3 from this zip archive to the following folder:
C:\Program Files\Common Files\VST3

In some cases it could be:
C:\Program Files (x86)\Common Files\VST3

Usage notes:
-----------
- Hold down the Shift key to adjust the sliders more precisely.
- Click in the lower right corner to toggle the GUI size between Normal and Large.
- The "Fader Link" function works reliably only in the graphical user interface. In the "generic" or "controls" view of some DAW hosts, the link works, but the output fader change is not displayed.

Further informations and tutorials can be found at https://loudmax.blogspot.com

